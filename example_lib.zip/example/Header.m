// I'm an example implementation
#import "Header.h"

@implementation Header

+ (void)sayHello {
  NSLog(@"Hello world");
}

@end
