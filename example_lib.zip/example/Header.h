// I'm an example header!
#import <Foundation/Foundation.h>

@interface Header : NSObject {

}

+ (void)sayHello;

@end
